import React from "react";
import Index from "./index";
import Header from "./header";

function App(){
    return(
        <>
        
        <Header/>
        
        </>
    )
}


export default App;