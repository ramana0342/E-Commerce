import "./App.css";


function SheimerEffect(){
return(
    <>

<div className="container sheimer-container">
    <div className="row row-cols-1 row-cols-md-4 g-4">


    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>


    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>


    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>


    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>

    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>

    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>


    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>


    
    <div class="col">
    <div class="card sheimer-card" aria-hidden="true">
  
  <div className="card-body">
    <h5 className="card-title placeholder-glow">
      <div className="placeholder col-12 img-placeholder card-img-top initial-image"></div>
    </h5>
    <p class="card-text placeholder-glow">
      <span className="placeholder col-8"></span> 
      <br></br>
      <span className="placeholder col-6"></span>
      <br></br>
      <span className="placeholder col-8"></span>
      <br></br>
      <span className="placeholder col-4"></span>
     
    </p>
    </div>
     </div>
    </div>



</div>
</div>
    
    
    
    </>
)
}

export default SheimerEffect;